from fastapi import FastAPI, APIRouter, HTTPException, Depends, Response, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
from passlib.context import CryptContext
from jose import JWTError, jwt
import json

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Security
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key-change-in-production-12345')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days

# WebSocket manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: dict[str, WebSocket] = {}

    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept()
        self.active_connections[user_id] = websocket

    def disconnect(self, user_id: str):
        if user_id in self.active_connections:
            del self.active_connections[user_id]

    async def send_notification(self, user_id: str, message: dict):
        if user_id in self.active_connections:
            try:
                await self.active_connections[user_id].send_text(json.dumps(message))
            except:
                self.disconnect(user_id)

manager = ConnectionManager()

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Models
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    name: str
    email: EmailStr
    created_at: str

class GigCreate(BaseModel):
    title: str
    description: str
    budget: float

class Gig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    title: str
    description: str
    budget: float
    status: str  # open, assigned
    owner_id: str
    owner_name: str
    created_at: str

class BidCreate(BaseModel):
    message: str
    price: float

class Bid(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    gig_id: str
    freelancer_id: str
    freelancer_name: str
    message: str
    price: float
    status: str  # pending, hired, rejected
    created_at: str

class Notification(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    user_id: str
    message: str
    read: bool
    created_at: str

# Helper functions
def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user = await db.users.find_one({"id": user_id}, {"_id": 0})
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    
    return user

# Auth routes
@api_router.post("/auth/register")
async def register(user_data: UserCreate, response: Response):
    # Check if user exists
    existing_user = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create user
    user_id = str(uuid.uuid4())
    user_doc = {
        "id": user_id,
        "name": user_data.name,
        "email": user_data.email,
        "password": hash_password(user_data.password),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.users.insert_one(user_doc)
    
    # Create token
    access_token = create_access_token(data={"sub": user_id})
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        samesite="lax"
    )
    
    return {
        "user": {
            "id": user_id,
            "name": user_data.name,
            "email": user_data.email,
            "created_at": user_doc["created_at"]
        }
    }

@api_router.post("/auth/login")
async def login(credentials: UserLogin, response: Response):
    user = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user or not verify_password(credentials.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = create_access_token(data={"sub": user["id"]})
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        max_age=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        samesite="lax"
    )
    
    return {
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "created_at": user["created_at"]
        }
    }

@api_router.post("/auth/logout")
async def logout(response: Response):
    response.delete_cookie("access_token")
    return {"message": "Logged out successfully"}

@api_router.get("/auth/me")
async def get_me(user: dict = Depends(get_current_user)):
    return {
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "created_at": user["created_at"]
        }
    }

# Gig routes
@api_router.post("/gigs", response_model=Gig)
async def create_gig(gig_data: GigCreate, user: dict = Depends(get_current_user)):
    gig_id = str(uuid.uuid4())
    gig_doc = {
        "id": gig_id,
        "title": gig_data.title,
        "description": gig_data.description,
        "budget": gig_data.budget,
        "status": "open",
        "owner_id": user["id"],
        "owner_name": user["name"],
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.gigs.insert_one(gig_doc)
    return Gig(**gig_doc)

@api_router.get("/gigs", response_model=List[Gig])
async def get_gigs(search: Optional[str] = None):
    query = {}
    if search:
        query["title"] = {"$regex": search, "$options": "i"}
    
    gigs = await db.gigs.find(query, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return [Gig(**gig) for gig in gigs]

@api_router.get("/gigs/{gig_id}", response_model=Gig)
async def get_gig(gig_id: str):
    gig = await db.gigs.find_one({"id": gig_id}, {"_id": 0})
    if not gig:
        raise HTTPException(status_code=404, detail="Gig not found")
    return Gig(**gig)

# Bid routes
@api_router.post("/gigs/{gig_id}/bids", response_model=Bid)
async def create_bid(gig_id: str, bid_data: BidCreate, user: dict = Depends(get_current_user)):
    # Check if gig exists and is open
    gig = await db.gigs.find_one({"id": gig_id}, {"_id": 0})
    if not gig:
        raise HTTPException(status_code=404, detail="Gig not found")
    if gig["status"] != "open":
        raise HTTPException(status_code=400, detail="Gig is no longer open")
    
    # Check if user already bid
    existing_bid = await db.bids.find_one({"gig_id": gig_id, "freelancer_id": user["id"]}, {"_id": 0})
    if existing_bid:
        raise HTTPException(status_code=400, detail="You have already bid on this gig")
    
    # Create bid
    bid_id = str(uuid.uuid4())
    bid_doc = {
        "id": bid_id,
        "gig_id": gig_id,
        "freelancer_id": user["id"],
        "freelancer_name": user["name"],
        "message": bid_data.message,
        "price": bid_data.price,
        "status": "pending",
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.bids.insert_one(bid_doc)
    return Bid(**bid_doc)

@api_router.get("/gigs/{gig_id}/bids", response_model=List[Bid])
async def get_gig_bids(gig_id: str, user: dict = Depends(get_current_user)):
    # Check if user is gig owner
    gig = await db.gigs.find_one({"id": gig_id}, {"_id": 0})
    if not gig:
        raise HTTPException(status_code=404, detail="Gig not found")
    if gig["owner_id"] != user["id"]:
        raise HTTPException(status_code=403, detail="Only gig owner can view bids")
    
    bids = await db.bids.find({"gig_id": gig_id}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return [Bid(**bid) for bid in bids]

@api_router.patch("/bids/{bid_id}/hire")
async def hire_bid(bid_id: str, user: dict = Depends(get_current_user)):
    # Get bid
    bid = await db.bids.find_one({"id": bid_id}, {"_id": 0})
    if not bid:
        raise HTTPException(status_code=404, detail="Bid not found")
    
    # Get gig and verify ownership
    gig = await db.gigs.find_one({"id": bid["gig_id"]}, {"_id": 0})
    if not gig:
        raise HTTPException(status_code=404, detail="Gig not found")
    if gig["owner_id"] != user["id"]:
        raise HTTPException(status_code=403, detail="Only gig owner can hire")
    if gig["status"] != "open":
        raise HTTPException(status_code=400, detail="Gig is already assigned")
    
    # Use MongoDB transaction for atomic update
    async with await client.start_session() as session:
        async with session.start_transaction():
            # Update gig status
            await db.gigs.update_one(
                {"id": bid["gig_id"]},
                {"$set": {"status": "assigned"}},
                session=session
            )
            
            # Update hired bid
            await db.bids.update_one(
                {"id": bid_id},
                {"$set": {"status": "hired"}},
                session=session
            )
            
            # Reject all other bids
            await db.bids.update_many(
                {"gig_id": bid["gig_id"], "id": {"$ne": bid_id}},
                {"$set": {"status": "rejected"}},
                session=session
            )
            
            # Create notification
            notification_id = str(uuid.uuid4())
            notification_doc = {
                "id": notification_id,
                "user_id": bid["freelancer_id"],
                "message": f"You have been hired for {gig['title']}",
                "read": False,
                "created_at": datetime.now(timezone.utc).isoformat()
            }
            await db.notifications.insert_one(notification_doc, session=session)
            
            # Send real-time notification
            await manager.send_notification(
                bid["freelancer_id"],
                {
                    "type": "hired",
                    "message": f"You have been hired for {gig['title']}",
                    "notification": notification_doc
                }
            )
    
    return {"message": "Freelancer hired successfully"}

# User's gigs and bids
@api_router.get("/my/gigs", response_model=List[Gig])
async def get_my_gigs(user: dict = Depends(get_current_user)):
    gigs = await db.gigs.find({"owner_id": user["id"]}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return [Gig(**gig) for gig in gigs]

@api_router.get("/my/bids", response_model=List[Bid])
async def get_my_bids(user: dict = Depends(get_current_user)):
    bids = await db.bids.find({"freelancer_id": user["id"]}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return [Bid(**bid) for bid in bids]

# Notifications
@api_router.get("/notifications", response_model=List[Notification])
async def get_notifications(user: dict = Depends(get_current_user)):
    notifications = await db.notifications.find({"user_id": user["id"]}, {"_id": 0}).sort("created_at", -1).to_list(100)
    return [Notification(**notif) for notif in notifications]

@api_router.patch("/notifications/{notification_id}/read")
async def mark_notification_read(notification_id: str, user: dict = Depends(get_current_user)):
    result = await db.notifications.update_one(
        {"id": notification_id, "user_id": user["id"]},
        {"$set": {"read": True}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Notification not found")
    return {"message": "Notification marked as read"}

# WebSocket endpoint
@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str):
    await manager.connect(websocket, user_id)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(user_id)

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()